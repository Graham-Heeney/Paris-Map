package com.example.paris;

import javafx.fxml.Initializable;
import java.net.URL;
import java.util.*;

public class Graph implements Initializable {

    // A static graph object to represent the graph
    public static Graph graph;

    // A adjacency list to represent vertices on the graph
    static Map<InterestPoints, List<InterestPoints>> adjacencyList = new HashMap<>();
    private List<InterestPoints> waypoints = new ArrayList<>();
    private Set<InterestPoints> avoidPoints = new HashSet<>();

    // Initialize the Graph object
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        graph = this;  // Set the static graph object to this instance
        // Optionally, you could initialize your graph here if you have static data
    }

    // Method to get the set of neighbors of a given point
    public Set<InterestPoints> getNeighbors(InterestPoints point) {
        // Ensure there is always a list for every point, even if it's empty
        return new HashSet<>(adjacencyList.getOrDefault(point, Collections.emptyList()));
    }

    // Method to add an edge between two points
    public static void addEdge(InterestPoints one, InterestPoints two) {
        adjacencyList.putIfAbsent(one, new ArrayList<>());  // Ensure there is a list for 'one'
        adjacencyList.get(one).add(two);

        adjacencyList.putIfAbsent(two, new ArrayList<>());  // Ensure there is a list for 'two'
        adjacencyList.get(two).add(one);  // For undirected graph, add both directions
    }

    // Method to find the shortest path between two points using BFS
    public Path bfsAlgorithm(InterestPoints start, InterestPoints end) {
        // Check if the start or end point is null, if so, cannot perform BFS
        if (start == null || end == null) {
            System.out.println("Start or end point is null, cannot perform BFS");
            return null;  // Return null indicating the BFS cannot be performed
        }

        // Map to store the path data, linking each point to its predecessor
        Map<InterestPoints, InterestPoints> previous = new HashMap<>();
        // Queue to manage the BFS front, adding nodes as they are to be processed
        Queue<InterestPoints> queue = new LinkedList<>();
        // Set to keep track of all visited nodes to prevent revisiting
        Set<InterestPoints> visited = new HashSet<>();

        // Initialize the BFS: Add the start point to the queue and mark it as visited
        queue.add(start);
        visited.add(start);
        // Start point has no predecessor, so it is put in the map with a null value
        previous.put(start, null);
        // Log the beginning of the BFS journey
        System.out.println("Starting BFS from: " + start.getPointName() + " to " + end.getPointName());

        // Process the queue until it is empty
        while (!queue.isEmpty()) {
            // Remove the head of the queue, this is the current node being visited
            InterestPoints current = queue.poll();
            // Log visiting the current node
            System.out.println("Visiting: " + current.getPointName());

            // If the current node is the end point, reconstruct and return the path
            if (current.equals(end)) {
                return reconstructPath(previous, end);  // Reconstruct the path from start to end using the 'previous' map
            }

            // Explore all neighbors of the current node
            for (InterestPoints neighbor : getNeighbors(current)) {
                // Check if the neighbor has not been visited
                if (!visited.contains(neighbor)) {
                    // Mark the neighbor as visited
                    visited.add(neighbor);
                    // Add the neighbor to the queue for future exploration
                    queue.add(neighbor);
                    // Link the neighbor to the current node in the 'previous' map
                    previous.put(neighbor, current);
                    // Log the addition of the neighbor to the queue
                    System.out.println("Enqueue: " + neighbor.getPointName());
                }
            }
        }
        // If the queue is empty and no path was found, log and return null
        System.out.println("No path found between the given stations.");
        return null;
    }



    private Path reconstructPath(Map<InterestPoints, InterestPoints> previous, InterestPoints end) {
        LinkedList<InterestPoints> path = new LinkedList<>();
        for (InterestPoints at = end; at != null; at = previous.get(at)) {
            System.out.println("Tracing path back to: " + (at != null ? at.getPointName() : "null"));
            path.addFirst(at);
        }
        return new Path(path);
    }



    // Method to find the shortest path using Dijkstra's Algorithm
    public Path dijkstraAlgorithm(Set<InterestPoints> allPoints, InterestPoints start, InterestPoints end) {
        // Map to hold the shortest known distance to each station from the start
        Map<InterestPoints, Double> distances = new HashMap<>();
        // Map to trace the optimal path back from each node
        Map<InterestPoints, InterestPoints> previous = new HashMap<>();
        // Priority queue to select the next station to visit based on the shortest known distance
        PriorityQueue<InterestPoints> queue = new PriorityQueue<>(Comparator.comparing(distances::get));

        // Initialize distances to all stations as infinity, since initially they are unreachable
        for (InterestPoints station : allPoints) {
            distances.put(station, Double.MAX_VALUE);
        }
        // Set the distance to the start point as 0 since it is the starting point
        distances.put(start, 0.0);
        // Add the start point to the priority queue
        queue.add(start);

        // Process each point in the queue
        while (!queue.isEmpty()) {
            // Remove the point with the shortest distance from the queue
            InterestPoints current = queue.poll();
            // If the current station is the end point, use the previous map to reconstruct and return the path
            if (current.equals(end)) {
                return reconstructPath(previous, end);
            }

            // Iterate through all direct neighbors of the current station
            for (InterestPoints neighbor : getNeighbors(current)) {
                // Calculate the distance to this neighbor assuming the distance from current to neighbor is 1
                double alt = distances.get(current) + 1; // This example assumes each edge has a weight of 1
                // If the calculated distance is shorter than the previously known distance to this neighbor
                if (alt < distances.get(neighbor)) {
                    // Update the shortest distance to this neighbor
                    distances.put(neighbor, alt);
                    // Record that reaching this neighbor optimally is done via the current station
                    previous.put(neighbor, current);
                    // Add the neighbor to the queue to explore its neighbors later
                    queue.add(neighbor);
                }
            }
        }
        // If the loop completes without returning a path, return null indicating no path was found
        return null;
    }



    // Method to perform DFS search for a path between two points
    public Path dfsSearch(InterestPoints start, InterestPoints end) {
        Set<InterestPoints> visited = new HashSet<>();
        LinkedList<InterestPoints> path = new LinkedList<>();

        // Perform DFS from the start point
        DFS(start, end, visited, path);

        // If the end point is reached during DFS, return the path
        if (!path.isEmpty() && path.getLast().equals(end)) {
            return new Path(path);
        } else {
            System.out.println("No path found between the given points.");
            return null;
        }
    }

    // Recursive DFS method
    private boolean DFS(InterestPoints current, InterestPoints end, Set<InterestPoints> visited, LinkedList<InterestPoints> path) {
        // Mark the current node as visited and add it to the path
        visited.add(current);
        path.add(current);

        // If the current node is the end node, return true to indicate path found
        if (current.equals(end)) {
            return true;
        }

        // Explore neighbors of the current node
        for (InterestPoints neighbor : getNeighbors(current)) {
            if (!visited.contains(neighbor)) {
                // If a path is found from this neighbor to the end node, return true
                if (DFS(neighbor, end, visited, path)) {
                    return true;
                }
            }
        }

        // If no path found from current node, backtrack and remove it from the path
        path.removeLast();
        return false;
    }

    public List<InterestPoints> getWaypoints() {
        return this.waypoints;
    }

    public Set<InterestPoints> getAvoidPoints() {
        return this.avoidPoints;
    }
}
