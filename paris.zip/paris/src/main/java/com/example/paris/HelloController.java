package com.example.paris;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.*;

import static com.example.paris.Graph.addEdge;
import static com.example.paris.Graph.adjacencyList;

public class HelloController implements Initializable {
    public static HelloController maincon;

    private Graph graph = new Graph(); //Will be used to store the graph

    private Map<String, InterestPoints> points = new HashMap<>(); //Will be used to store all points

    @FXML
    public Button clearMap;

    @FXML
    public MenuButton waypointPoint;

    @FXML
    public AnchorPane mapPane;

    @FXML
    public Button bfsSearchButton;

    @FXML
    public ImageView mapImageView;

    @FXML
    public ListView routeOutput;
    @FXML
    public  ListView waypointListview;
    @FXML
    public ListView avoidListview;

    @FXML
    public Button initialiseMapButton;

    @FXML
    public Button dfsSearchButton;

    @FXML
    public Button addAvoidPointButton;

    @FXML
    public MenuButton startPoint;

    @FXML
    public MenuButton destinationPoint;

    @FXML
    public MenuButton avoidPoint;


    private InterestPoints selectedWaypointPoint;
    private Map<String, InterestLines> lines;

    private Circle firstPointRing;

    private Circle destinationPointCircle;

    private Circle firstPointCircle;

    private InterestPoints selectedDestinationPoint;

    private InterestPoints firstSelectedPoint;

    private Circle destinationPointOuterRing;

    private boolean isMapPopulated = false;

    private Map<String, GraphNode<String>> graphNodes;
    private AdjacencyMatrix am;
//this method is used to load all the locations onto the map when you press map points
    public void initialiseMap(ActionEvent actionEvent) {
        // Check if the map is populated
        if (isMapPopulated) {
            System.out.println("Map already populated");
            return;
        }
        String csvData =

                "Le Marais,Eiffel Tower,df002c,133,114\n" +
                        "7th Arrondissement,Louvre Museum,df002c,148,37\n" +
                        "Île de la Cité,Notre-Dame Cathedral,df002c,78,83\n" +
                        "18th Arrondissement,Montmartre,df002c,113,211\n" +
                        "8th Arrondissement,Champs-Élysées,df002c,251,171\n" +
                        "Île de la Cité,Sainte-Chapelle,df002c,297,34\n" +
                        "Montmartre,Sacre-Coeur,df002c,103,247\n" +
                        "1st Arrondissement,Place Vendome,df002c,166,193\n"+

                        "Île de la Cité,Sainte-Chapelle,f7ff0d,297,34\n" +
                        "6th Arrondissement,Luxembourg Gardens,f7ff0d,475,41\n" +
                        "7th Arrondissement,Musée d'Orsay,f7ff0d,409,85\n" +
                        "Along the Seine,Seine River,f7ff0d,314,120\n" +
                        "Montmartre,Sacre-Coeur,f7ff0d,103,247\n" +
                        "1st Arrondissement,Place Vendome,f7ff0d,166,193\n"+


                        "6th Arrondissement,Luxembourg Gardens,ff0df3,475,41\n" +
                        "7th Arrondissement,Musée d'Orsay,ff0df3,409,85\n" +
                        "9th Arrondissement,Palais Garnier,ff0df3,515,129\n" +



                        "7th Arrondissement,Musée d'Orsay,3238ed,409,85\n" +
                        "Along the Seine,Seine River,3238ed,314,120\n" +
                        "5th Arrondissement,Panthéon,3238ed,449,164\n" +
                        "3rd Arrondissement,Picasso Museum,3238ed,301,203\n" +


                        "3rd Arrondissement,Picasso Museum,7a7a87,301,203\n" +
                        "8th Arrondissement,Champs-Élysées,7a7a87,251,171\n" +
                        "Along the Seine,Seine River,7a7a87,314,120\n" +


                        "3rd Arrondissement,Picasso Museum,ff0fff,301,203\n" +
                        "7th Arrondissement,Rodin Museum,ff0fff,238,305\n" +


                        "7th Arrondissement,Rodin Museum,168c4d,238,305\n" +
                        "20th Arrondissement,Père Lachaise Cemetery,168c4d,148,286\n" +
                        "4th Arrondissement,Centre Pompidou,168c4d,241,369\n" +
                        "7th Arrondissement,Les Invalides,168c4d,330,356\n" +


                        "8th Arrondissement,Place de la Concorde,349efa,374,222\n" +
                        "7th Arrondissement,Les Invalides,349efa,330,356\n" +


                        "7th Arrondissement,Les Invalides,f5146e,330,356\n" +
                        "1st Arrondissement,Tuileries Garden,f5146e,395,372\n" +


                        "1st Arrondissement,Tuileries Garden,14c0f5,395,372\n" +
                        "Île de la Cité,Île de la Cité,14c0f5,473,318\n" +
                        "5th Arrondissement,Latin Quarter,14c0f5,512,358\n" +
                        "18th Arrondissement,Moulin Rouge,14c0f5,605,295\n" +


                        "4th Arrondissement,Le Marais,6614f5,481,259\n" +
                        "18th Arrondissement,Moulin Rouge,6614f5,605,295\n" +
                        "Île de la Cité,Île de la Cité,6614f5,473,318\n" +


                        "20th Arrondissement,Père Lachaise Cemetery,020eed,148,286\n" +
                        "18th Arrondissement,Montmartre,020eed,113,211\n" +
                        "16th Arrondissement,Trocadéro Gardens,020eed,56,376\n" +



                        "5th Arrondissement,Panthéon,027d25,449,164\n" +
                        "8th Arrondissement,Place de la Concorde,027d25,374,222\n" +
                        "4th Arrondissement,Le Marais,027d25,481,259\n" +
                        "9th Arrondissement,Palais Garnier,027d25,515,129\n" +


                        "9th Arrondissement,Palais Garnier,b06cf5,515,129\n" +
                        "1st Arrondissement,Forum des Halles,b06cf5,650,89\n" +

                        "17th Arrondissement,Parc Monceau,b06cf5,561,193\n";




        createAndConnectGraphNodes(csvData);
        Map<String, InterestLines> lines = parseCSVData(csvData);
        // Iterate over the lines and print their points
        for (Map.Entry<String, InterestLines> entry : lines.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue().getLineColor());
            for (InterestPoints point : entry.getValue().getPoints()) {
                System.out.println("\t" + point.getPointName() + " (" + point.getXcoord() + "," + point.getYcoord() + ")");
            }
            System.out.println("\n");
        }

        populateMenuButtons(lines);


        //After filling the map, set the boolean to true.
        isMapPopulated = true;
    }

    // Defines a method to parse CSV data and return a map linking line names to InterestLines objects
    private Map<String, InterestLines> parseCSVData(String csvData) {
        // Initialize a new HashMap to store line names and their corresponding InterestLines objects
        lines = new HashMap<>();
        // This will hold the last point in each loop for connecting with the current point
        InterestPoints lastPoint = null;

        // Split the csvData string into an array, each element is a line from the CSV
        String[] csvLines = csvData.split("\n");

        // Iterate over each line in the CSV data
        for (String line : csvLines) {
            // Split the line into parts wherever there is a comma
            String[] values = line.split(",");

            // Check if the line has exactly 5 elements
            if (values.length != 5) {
                // Print an error message if a line does not have exactly 5 elements
                System.err.println("Invalid line in CSV: " + line);
                continue;
            }

            // Extract and trim the name of the line and the point from the split line data
            String lineName = values[0].trim();
            String pointName = values[1].trim();
            // Parse the x and y coordinates from the line data, assumed to be at index 3 and 4
            double x = Double.parseDouble(values[3].trim());
            double y = Double.parseDouble(values[4].trim());

            // Retrieve or create a new InterestLines object for the current line
            InterestLines lineObj = lines.get(lineName);
            if (lineObj == null) {
                lineObj = new InterestLines(lineName);
                lines.put(lineName, lineObj);
            }

            // Retrieve or create a new InterestPoints object for the current point
            InterestPoints PointObj = points.get(pointName);
            if (PointObj == null) {
                PointObj = new InterestPoints(pointName, x, y);
                points.put(pointName, PointObj);
            }

            // Add the point to the Line object's list of points
            lineObj.addPoint(PointObj);

            // If lastPoint is not null, establish a connection with the current point
            if (lastPoint != null) {
                // Here is where you add edges between points
                addEdge(lastPoint, PointObj);

                // Calculate the Euclidean distance between the current point and the last point
                double distance = Math.sqrt(Math.pow(PointObj.getXcoord() - lastPoint.getXcoord(), 2)
                        + Math.pow(PointObj.getYcoord() - lastPoint.getYcoord(), 2));
                // Output the distances between points for verification or debugging
                System.out.println("Calculating distance between " + lastPoint.getPointName() + " and " + PointObj.getPointName());
                System.out.println("Previous point coordinates: " + lastPoint.getXcoord() + ", " + lastPoint.getYcoord());
                System.out.println("Current point coordinates: " + PointObj.getXcoord() + ", " + PointObj.getYcoord());
                System.out.println("Calculated distance: " + distance);

                // Add neighbors to each point if not already present to facilitate connections between them
                if (!lastPoint.getNeighborPoints().containsKey(PointObj)) {
                    lastPoint.addNeighbor(PointObj);
                    System.out.println("Added " + PointObj.getPointName() + " as a neighbor to " + lastPoint.getPointName());
                }
                if (!PointObj.getNeighborPoints().containsKey(lastPoint)) {
                    PointObj.addNeighbor(lastPoint);
                    System.out.println("Added " + lastPoint.getPointName() + " as a neighbor to " + PointObj.getPointName());
                }
            }

            // Update lastPoint to the current one for the next iteration
            lastPoint = PointObj;
        }
        // Return the map of lines to their respective InterestLines objects
        return lines;
    }


    // Define a method to handle menu item clicks in a user interface
    private void handleMenuClick(ActionEvent event, InterestPoints point) {
        // Get the source of the action event and cast it to a MenuItem
        MenuItem clickedMenuItem = (MenuItem) event.getSource();
        // Retrieve the parent MenuButton of the clicked menu item from the popup it belongs to
        MenuButton parentMenuButton = (MenuButton) clickedMenuItem.getParentPopup().getOwnerNode();

        // Set the name of the selected point as the text on the parent MenuButton
        parentMenuButton.setText(point.getPointName());

        // Check if the parent MenuButton is the one used for selecting the start point
        if (parentMenuButton == startPoint) {
            // If so, update the firstSelectedPoint variable to the current point
            firstSelectedPoint = point;
            // Call a method to visually represent this selection on the map or UI
            drawFirstCircle(point);
        } else if (parentMenuButton == destinationPoint) { // Check if it's the button for the destination point
            // Update the selectedDestinationPoint variable to the current point
            selectedDestinationPoint = point;
            // Call a method to visually represent the destination point on the map
            drawDestinationCircle(point);
        }
    }

    private void populateMenuButtons(Map<String, InterestLines> lines) {
        Set<InterestPoints> uniquePointsSet = new HashSet<>();
        // Loop through each InterestPoints object in the lines Map
        for (InterestLines line : lines.values()) {
            // Loop through each Point object in the Interestline's points
            // Add the point to the uniquePoints set
            uniquePointsSet.addAll(line.getPoints());
        }
        // Convert the Set to a List
        List<InterestPoints> uniquePointsList = new ArrayList<>(uniquePointsSet);
        // Sort list of points alphabetically
        uniquePointsList.sort(Comparator.comparing(InterestPoints::getPointName));
        // Add the points to the menu button
        avoidPoint.getItems().addAll(createPointMenuItems(uniquePointsList));
        waypointPoint.getItems().addAll(createPointMenuItems(uniquePointsList));
        startPoint.getItems().addAll(createPointMenuItems(uniquePointsList));
        destinationPoint.getItems().addAll(createPointMenuItems(uniquePointsList));
    }

    // Method to create a list of MenuItem objects from a list of InterestPoints
    private List<MenuItem> createPointMenuItems(List<InterestPoints> points) {
        // Initialize a new ArrayList to store MenuItem objects
        List<MenuItem> pointMenuItems = new ArrayList<>();

        // Loop through each InterestPoint in the provided list
        for (InterestPoints point : points) {
            // Create a new MenuItem using the name of the interest point
            MenuItem menuItem = new MenuItem(point.getPointName());

            // Set an action on the MenuItem to handle clicks; lambda expression captures 'point'
            menuItem.setOnAction(e -> handleMenuClick(e, point));

            // Add the newly created MenuItem to the list of MenuItems
            pointMenuItems.add(menuItem);
        }

        // Return the list of MenuItem objects
        return pointMenuItems;
    }




/// MAP METHODS


    // Define a method to create and connect graph nodes from CSV formatted data
    public void createAndConnectGraphNodes(String csvData) {
        // Initialize a HashMap to store graph nodes indexed by location name
        graphNodes = new HashMap<>();
        // Create an AdjacencyMatrix with a specified size to store connections between nodes
        am = new AdjacencyMatrix(100);

        // Split the CSV data into individual lines
        String[] csvLines = csvData.split("\n");
        // Iterate over each line in the CSV data
        for (String line : csvLines) {
            // Split the line into parts using a comma as the delimiter
            String[] parts = line.split(",");
            // Check if the line does not have exactly 7 elements as expected
            if (parts.length != 7) {
                // Print a message and skip processing this malformed line
                System.out.println("Skipping malformed line: " + line);
                continue;
            }

            // Trim spaces and retrieve start and end locations from the line
            String startLocation = parts[0].trim();
            String endLocation = parts[1].trim();
            // Parse the starting and ending x, y coordinates from the line
            int xStart = Integer.parseInt(parts[3].trim());
            int yStart = Integer.parseInt(parts[4].trim());
            int xEnd = Integer.parseInt(parts[5].trim());
            int yEnd = Integer.parseInt(parts[6].trim());

            // Retrieve or create graph nodes for the start and end locations with their coordinates
            // If node does not exist, a new one is created using the location name and coordinates
            GraphNode<String> startNode = graphNodes.computeIfAbsent(startLocation,
                    name -> new GraphNode<>(name, xStart, yStart, am));
            GraphNode<String> endNode = graphNodes.computeIfAbsent(endLocation,
                    name -> new GraphNode<>(name, xEnd, yEnd, am));

            // Connect the start node to the end node in an undirected manner
            startNode.connectToNodeUndirected(endNode);
        }
    }


    // This method draws a line between each point on the path
    private void drawShortestPath(Path shortestRoute) {
        // Remove any existing lines from the mapPane
        mapPane.getChildren().removeIf(node -> node instanceof javafx.scene.shape.Line);
        // Get the list of points in the shortest path
        List<InterestPoints> shortestPath = shortestRoute.getPath();
        // Draw a line between each pair of adjacent points in the shortest path
        for (int i = 0; i < shortestPath.size() - 1; i++) {
            InterestPoints start = shortestPath.get(i);
            InterestPoints end = shortestPath.get(i + 1);
            drawLineBetweenPoints(start, end, Color.BLACK);
        }
    }


    //Based on the scale of the map image and the relative coordinates, this method computes the precise coordinates of a point on the mapPane.
    private Point2D calculateActualCoordinates(InterestPoints point) {
        double scaleX = mapImageView.getBoundsInLocal().getWidth() / mapImageView.getImage().getWidth();
        double scaleY = mapImageView.getBoundsInLocal().getHeight() / mapImageView.getImage().getHeight();

        double actualX = point.getXcoord() * scaleX;
        double actualY = point.getYcoord() * scaleY;

        return new Point2D(actualX, actualY);
    }

    //By utilizing the point's precise coordinates, this method generates a colored circle to represent the point on the map.
    private void createPointCircle(Circle innerCircle, Circle outerRing, InterestPoints point, Color color) {
        // Calculate the coordinates of the point on the mapPane
        Point2D actualCoordinates = calculateActualCoordinates(point);

        // Set the radius and centre of the circle
        innerCircle.setCenterX(actualCoordinates.getX());
        innerCircle.setCenterY(actualCoordinates.getY());
        innerCircle.setRadius(5);
        innerCircle.setFill(color);

        outerRing.setCenterX(actualCoordinates.getX());
        outerRing.setCenterY(actualCoordinates.getY());
        outerRing.setRadius(5); // Slightly larger radius for the outer ring
        outerRing.setFill(Color.TRANSPARENT);
        outerRing.setStroke(color);
        outerRing.setStrokeWidth(2);
    }


    // this method draws the circle we have already on a starting point blue
    private void drawFirstCircle(InterestPoints point) {
        // Remove any existing circle
        if (firstPointCircle != null) {
            mapPane.getChildren().removeAll(firstPointCircle, firstPointRing);
        }
        // Makes a new circle on the point picked
        firstPointCircle = new Circle();
        firstPointRing = new Circle();
        createPointCircle(firstPointCircle, firstPointRing, point, Color.BLUE);
        // puts new circle on the map pane
        mapPane.getChildren().addAll(firstPointCircle, firstPointRing);
    }

    // This method draws an aqua circle on the selected destination
    private void drawDestinationCircle(InterestPoints point) {
        // Remove any existing end point circle and outer ring from the mapPane
        if (destinationPointCircle != null) {
            mapPane.getChildren().removeAll(destinationPointCircle, destinationPointOuterRing);
        }
        // Create a new circle and outer ring with the specified point and color
        destinationPointCircle = new Circle();
        destinationPointOuterRing = new Circle();
        createPointCircle(destinationPointCircle, destinationPointOuterRing, point, Color.RED);
        // Add the new circle and outer ring to the mapPane
        mapPane.getChildren().addAll(destinationPointCircle, destinationPointOuterRing);
    }



    // This method draws a line between two points with a given color
    private void drawLineBetweenPoints(InterestPoints start, InterestPoints end, Color color) {
        // Calculate the actual coordinates of the start and end points on the mapPane
        Point2D startPoint = calculateActualCoordinates(start);
        Point2D endPoint = calculateActualCoordinates(end);
        // Create a new line with the calculated start and end points and set its color and width
        javafx.scene.shape.Line line = new javafx.scene.shape.Line(startPoint.getX(), startPoint.getY(), endPoint.getX(), endPoint.getY());
        line.setStroke(color);
        line.setStrokeWidth(6);
        // Add the line to the mapPane
        mapPane.getChildren().add(line);
    }

    private double calculateDistance(double x1, double y1, double x2, double y2) {
        //Use Euclidean Formula to calculate the distance between two points
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
    }


    public void clearMap(ActionEvent actionEvent) {
        //clear lines
        mapPane.getChildren().removeIf(node -> node instanceof javafx.scene.shape.Line);
        //clear listview
        routeOutput.getItems().clear();
    }


    public void initialize(URL url, ResourceBundle resourceBundle) {
    }




    // AVOID POINTS AND WAYPOINTS METHODS

    @FXML
    public void addAvoidPoint(ActionEvent event) {
        // avoidPoint is a MenuButton for selecting points to avoid
        String avoidPointName = avoidPoint.getText();
        InterestPoints avoidPoint = points.get(avoidPointName);

        // Check if the avoidpoint is null (not selected or does not exist)
        if (avoidPoint == null) {
            System.out.println("No point selected or point does not exist.");
            return;
        }

        // Add the selected point to a set of points to avoid
        if (!graph.getAvoidPoints().contains(avoidPoint)) {
            graph.getAvoidPoints().add(avoidPoint);
            System.out.println("Point added to avoid list: " + avoidPoint.getPointName());

            // Update the list to display the current avoid points
            updateAvoidListView();
            //  recalculate routes to immediately reflect this change
            recalculateAndDisplayRoute();
        } else {
            System.out.println("Point already in avoid list.");
        }
    }

    // This method updates the ListView that displays the points to avoid.
    private void updateAvoidListView() {
        // Create a new ObservableList to hold the names of the points to avoid.
        ObservableList<String> avoidItems = FXCollections.observableArrayList();

        // Iterate over each point in the set of avoid points from the graph.
        for (InterestPoints point : graph.getAvoidPoints()) {
            // Add the name of each point to the observable list.
            avoidItems.add(point.getPointName());
        }

        // Set the items of the avoidListView to the newly created list of avoid points.
        // This updates the ListView to display the current list of points to avoid.
        avoidListview.setItems(avoidItems);
    }



    @FXML
    public void removeAvoidPoint(ActionEvent event) {
        // avoidPoint is a MenuButton for selecting points to avoid
        String avoidPointName = avoidPoint.getText();
        InterestPoints avoidPoint = points.get(avoidPointName);

        // Check if the point is null (not selected or does not exist)
        if (avoidPoint == null) {
            System.out.println("No point selected or point does not exist.");
            return;
        }

        // Remove the selected point from the set of points to avoid
        if (graph.getAvoidPoints().contains(avoidPoint)) {
            graph.getAvoidPoints().remove(avoidPoint);
            System.out.println("Point removed from avoid list: " + avoidPoint.getPointName());

            // Update the list to display the current avoid points
            updateAvoidListView();
            // Optionally recalculate routes to immediately reflect this change
            recalculateAndDisplayRoute();
        } else {
            System.out.println("Point not in avoid list.");
        }
    }



    @FXML
    public void removeWaypoint(ActionEvent event) {
        // waypointPoint is a MenuButton for selecting waypoints
        String waypointName = waypointPoint.getText();
        InterestPoints waypointToRemove = points.get(waypointName);

        // Check if the waypoint is null (not selected or does not exist)
        if (waypointToRemove == null) {
            System.out.println("No waypoint selected or waypoint does not exist.");
            return;
        }

        // Remove the selected waypoint from the list of waypoints in the graph
        if (graph.getWaypoints().contains(waypointToRemove)) {
            graph.getWaypoints().remove(waypointToRemove);
            System.out.println("Waypoint removed: " + waypointToRemove.getPointName());

            // Update the ListView displaying waypoints
            updateWaypointListView();

            // Recalculate the route to reflect the removal of the waypoint
            recalculateAndDisplayRoute();
        } else {
            System.out.println("Waypoint was not in the list.");
        }
    }

    // This method updates the ListView that displays the waypoints in the graph.
    private void updateWaypointListView() {
        // Create a new ObservableList to hold the names of waypoints.
        ObservableList<String> waypointItems = FXCollections.observableArrayList();

        // Iterate over each waypoint in the graph's collection of waypoints.
        for (InterestPoints wp : graph.getWaypoints()) {
            // Add the name of each waypoint to the observable list.
            waypointItems.add(wp.getPointName());
        }

        // Set the items of the waypointListview to the newly created list of waypoints.
        // This updates the ListView to display the current list of waypoints.
        waypointListview.setItems(waypointItems);
    }





    @FXML
    public void addWaypoint(ActionEvent event) {
        // Get the selected waypoint from the waypointPoint MenuButton
        String waypointName = waypointPoint.getText();
        InterestPoints waypoint = points.get(waypointName);
        // Check if the waypoint is null (not selected or does not exist)
        if (waypoint == null) {
            System.out.println("No waypoint selected or waypoint does not exist.");
            return;
        }
        // Add the selected point to a set of points to avoid
        if (!graph.getWaypoints().contains(waypoint)) {
            graph.getWaypoints().add(waypoint);
            System.out.println("Waypoint added: " + waypoint.getPointName());

            // Recalculate the route including the new waypoint
            recalculateAndDisplayRoute();
        } else {
            System.out.println("Waypoint already added.");
        }
    }

    private void recalculateAndDisplayRoute() {
        // Check if either the starting point (firstSelectedPoint) or the destination point (selectedDestinationPoint) is not selected
        if (firstSelectedPoint == null || selectedDestinationPoint == null) {
            // Print a message to the console asking the user to make sure both points are selected
            System.out.println("Please select both start and end points.");
            // Exit the method early as the necessary points are not available for processing
            return;
        }

        // Initialize a list to store the points forming the complete route
        List<InterestPoints> completeRoute = new ArrayList<>();
        // Set the current point to start processing from the first selected point
        InterestPoints currentPoint = firstSelectedPoint;


        // Clear previous route directions
        ObservableList<String> routeDescriptions = FXCollections.observableArrayList();

        // Add all waypoints in sequence plus the final destination this is how waypoints work
        List<InterestPoints> allPoints = new ArrayList<>(graph.getWaypoints());
        allPoints.add(selectedDestinationPoint);

        // Calculate the path from each point to the next
        for (InterestPoints nextPoint : allPoints) {
            Path pathSegment = findPath(currentPoint, nextPoint);
            if (pathSegment == null || pathSegment.getPath().isEmpty()) {
                System.out.println("No path found between " + currentPoint.getPointName() + " and " + nextPoint.getPointName());
                return;
            }
            // Avoid duplicating the last point of the previous segment as the first point of the next segment
            if (!completeRoute.isEmpty()) {
                completeRoute.remove(completeRoute.size() - 1);
            }
            completeRoute.addAll(pathSegment.getPath());
            currentPoint = nextPoint;

            // Add readable description for each segment
            routeDescriptions.add("Go from " + pathSegment.getPath().get(0).getPointName() +
                    " to " + pathSegment.getPath().get(pathSegment.getPath().size() - 1).getPointName());
        }

        // Update ListView with directions
        routeOutput.setItems(routeDescriptions);

        // Draw the continuous route without overlapping lines
        if (!completeRoute.isEmpty()) {
            drawShortestPath(new Path(completeRoute));  // Convert completeRoute to a Path object if necessary
        }
    }



    private Path findPath(InterestPoints start, InterestPoints end) {
        // Implement the pathfinding logic, e.g., using Dijkstra's algorithm
        return graph.dijkstraAlgorithm(new HashSet<>(points.values()), start, end);  // Placeholder
    }





    //PATH METHODS





    // Define a method to perform a breadth-first search (BFS)
    public void bfsSearch(ActionEvent actionEvent) {
        // Check if both start and end points are selected; if not, prompt the user and exit the method
        if (firstSelectedPoint == null || selectedDestinationPoint == null) {
            System.out.println("Please select both start and end points.");
            return;
        }

        // Use the BFS algorithm in the graph object to find the shortest route between the selected points
        Path shortestRoute = graph.bfsAlgorithm(firstSelectedPoint, selectedDestinationPoint);
        // Check if the returned path is null or empty, indicating no path could be found
        if (shortestRoute == null || shortestRoute.getPath().isEmpty()) {
            System.out.println("No path found between the selected points");
            return;
        }

        // Retrieve the path from the shortestRoute object
        List<InterestPoints> path = shortestRoute.getPath();
        // Print debug information showing the start and end of the path and the number of stops
        System.out.println("Debug: Path from " + path.get(0).getPointName() + " to " + path.get(path.size() - 1).getPointName() + " with " + shortestRoute.getStops() + " stops.");
        // Debug print each point visited along the path
        path.forEach(point -> System.out.println("Visited: " + point.getPointName()));

        // Visualize the shortest path on a map or diagram
        drawShortestPath(shortestRoute);

        // Create an observable list of strings for GUI display
        ObservableList<String> items = FXCollections.observableArrayList();
        // Add information about the path to the observable list
        items.add("BFS Path: " + path.get(0).getPointName() + " to " + path.get(path.size() - 1).getPointName());
        items.add("Edges (stops): " + (path.size() - 1));
        // Add each point's name to the observable list
        path.forEach(point -> items.add(point.getPointName()));
        // Set the items of a GUI component to display the results
        routeOutput.setItems(items);
    }
















    // Method to perform Dijkstra's search algorithm for finding the shortest path between two points and update the GUI with the results.
    public void dijkstraSearch(ActionEvent actionEvent) {
        // Check if both the start and end points have been selected; if not, prompt the user and exit the method
        if (firstSelectedPoint == null || selectedDestinationPoint == null) {
            System.out.println("Please select both start and end points.");
            return; // Exit the method if either point is not selected
        }

        // Retrieve all points from a collection holding the available points
        Set<InterestPoints> allPoints = new HashSet<>(points.values());
        // Call the Dijkstra algorithm with all points, starting and destination points
        Path shortestRoute = graph.dijkstraAlgorithm(allPoints, firstSelectedPoint, selectedDestinationPoint);

        // Check if a path was not found or is empty
        if (shortestRoute == null || shortestRoute.getPath().isEmpty()) {
            System.out.println("No path found between the selected points.");
            return; // Exit the method if no path exists
        }

        // Retrieve the path and create a formatter for displaying the distance
        List<InterestPoints> path = shortestRoute.getPath();
        DecimalFormat decimalFormat = new DecimalFormat("#.00");

        // Print the path and the total distance in the console for debugging
        System.out.println("Path from " + path.get(0).getPointName() + " to " + path.get(path.size() - 1).getPointName() +
                " with total distance: " + decimalFormat.format(shortestRoute.getDistance()) + " units.");
        // Print each point's name in the path for traceability
        path.forEach(point -> System.out.print(point.getPointName() + " -> "));
        System.out.println(); // Complete the line after printing all points

        // Update the map visualization with the shortest path
        drawShortestPath(shortestRoute);

        // Prepare the list for GUI display and add summary information
        ObservableList<String> items = FXCollections.observableArrayList();
        items.add("Dijkstra Path: " + path.get(0).getPointName() + " to " + path.get(path.size() - 1).getPointName());
        items.add("Total Distance: " + decimalFormat.format(shortestRoute.getDistance()) + " units");

        // Add each point in the path to the GUI list for display
        path.forEach(point -> items.add(point.getPointName()));
        routeOutput.setItems(items);
    }











    @FXML
    public void dfsSearch(ActionEvent actionEvent) {
        // Check if both start and end points are selected before proceeding.
        if (firstSelectedPoint == null || selectedDestinationPoint == null) {
            System.out.println("Please select both start and end points."); // Prompt user to select points if not already done.
            return; // Exit the method if the necessary points aren't selected.
        }

        // Create a list to store all paths found between the start and end points.
        List<List<InterestPoints>> allPaths = new ArrayList<>();

        // Create a list to store the current path being explored by DFS.
        List<InterestPoints> currentPath = new ArrayList<>();

        // Call the recursive DFS method to explore all possible paths between the start and end points.
        dfsAllPaths(firstSelectedPoint, selectedDestinationPoint, currentPath, allPaths);

        // Check if no paths were found after the search.
        if (allPaths.isEmpty()) {
            System.out.println("No path found between the selected points"); // Inform the user if no paths are found.
            return; // Exit the method if no paths are found.
        }

        // Update the graphical user interface with the results of the DFS.
        drawAllPaths(allPaths);

        // Prepare an observable list to display path information in the UI.
        ObservableList<String> items = FXCollections.observableArrayList();
        for (List<InterestPoints> path : allPaths) {
            String pathInfo = "DFS Path: "; // Begin formatting the path information.
            for (InterestPoints point : path) {
                pathInfo += point.getPointName() + " -> "; // Append each point's name followed by an arrow.
            }
            pathInfo = pathInfo.substring(0, pathInfo.length() - 4); // Remove the trailing arrow from the last point.
            items.add(pathInfo); // Add the formatted path information to the list of items.
        }
        routeOutput.setItems(items); // Update the ListView with the path information.
    }



    // Recursive DFS method to find all paths between start and end points
    private void dfsAllPaths(InterestPoints start, InterestPoints end, List<InterestPoints> path, List<List<InterestPoints>> allPaths) {
        // Add the current node to the path
        path.add(start);

        // If the start node is the end node, then a path from start to end has been completed
        if (start.equals(end)) {
            allPaths.add(new ArrayList<>(path)); // Add a copy of the current path to allPaths
        } else {
            // Continue searching through all neighbors that haven't been visited in the current path
            for (InterestPoints neighbor : graph.getNeighbors(start)) {
                if (!path.contains(neighbor)) { // Check if the neighbor has already been visited in the current path to avoid cycles
                    // Recursive call to explore further from the neighbor
                    dfsAllPaths(neighbor, end, path, allPaths);
                }
            }
        }

        // Backtrack: remove the current node from the path to explore other paths
        path.remove(path.size() - 1);
    }



    // Method to draw all paths on the mapPane
    private void drawAllPaths(List<List<InterestPoints>> allPaths) {
        // Define colors for drawing paths
        Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.ORANGE, Color.PURPLE, Color.YELLOW};

        // Counter for cycling through colors
        int colorIndex = 0;

        // Iterate through each path and draw it on the mapPane
        for (List<InterestPoints> path : allPaths) {
            Color color = colors[colorIndex % colors.length]; // Get color from the array

            // Draw each segment of the path
            for (int i = 0; i < path.size() - 1; i++) {
                InterestPoints startPoint = path.get(i);
                InterestPoints endPoint = path.get(i + 1);
                drawLineBetweenPoints(startPoint, endPoint, color);
            }

            colorIndex++; // Increment color index for next path
        }
    }









// UNUSED METHODS



    public List<InterestLines> getCommonLines(InterestPoints point1, InterestPoints point2) {
        // Initialize a new list with the lines of the first point
        List<InterestLines> commonLines = new ArrayList<>(point1.getLines());

        // Keep only the lines that are also present in the lines of the second point
        commonLines.retainAll(point2.getLines());

        // Return the list of shared lines
        return commonLines;
    }

    private InterestPoints findNearestPoint(double x, double y) {
        // Initialize variables to store the nearest point and its distance
        InterestPoints nearestPoint = null;
        double nearestDistance = Double.MAX_VALUE;

        // Iterate over all points to find the nearest one
        for (InterestPoints point : points.values()) {
            // Calculate the distance between the given coordinates and the point's coordinates
            double distance = calculateDistance(x, y, point.getXcoord(), point.getYcoord());

            // If the calculated distance is smaller than the current nearest distance,
            // update the nearest point and nearest distance
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearestPoint = point;
            }
        }
        return nearestPoint;
    }

    private void selectMenuItem(MenuButton menuButton, String pointName) {
        // Iterate through menuButton's items list and select item with matching pointName
        for (MenuItem item : menuButton.getItems()) {
            if (item.getText().equals(pointName)) {
                // Set menuButton's text to selected item's text
                menuButton.setText(item.getText());
                break;
            }
        }
    }

}


