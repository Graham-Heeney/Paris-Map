package com.example.paris;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GraphNodeTest {

    @Test
    void testNodeInitialization() {
        // Setting up the test environment within the test method
        AdjacencyMatrix matrix = new AdjacencyMatrix(2);
        GraphNode<String> nodeA = new GraphNode<>("Node A", 1.0, 1.0, matrix);

        // Assertions to check if the node is initialized correctly
        assertEquals("Node A", nodeA.data, "Data should match initialization data.");
        assertEquals(1.0, nodeA.x, "X coordinate should match initialization value.");
        assertEquals(1.0, nodeA.y, "Y coordinate should match initialization value.");
        assertNotNull(nodeA.visual, "Visual representation should not be null.");
        assertEquals(0, nodeA.nodeId, "Node ID should be initialized correctly.");
    }

    @Test
    void testConnectToNodeDirected() {
        // Setup within the method
        AdjacencyMatrix matrix = new AdjacencyMatrix(10); // larger matrix for multiple nodes
        GraphNode<String> nodeA = new GraphNode<>("Node A", 1.0, 1.0, matrix);
        GraphNode<String> nodeB = new GraphNode<>("Node B", 2.0, 2.0, matrix);

        // Connect nodes
        nodeA.connectToNodeDirected(nodeB);

        // Verify the connection is directed
        assertTrue(matrix.amat[nodeA.nodeId][nodeB.nodeId], "There should be a directed edge from nodeA to nodeB.");
        assertFalse(matrix.amat[nodeB.nodeId][nodeA.nodeId], "There should be no directed edge from nodeB to nodeA.");
    }

    @Test
    void testConnectToNodeUndirected() {
        // Setup within the method
        AdjacencyMatrix matrix = new AdjacencyMatrix(10); // larger matrix for multiple nodes
        GraphNode<String> nodeA = new GraphNode<>("Node A", 1.0, 1.0, matrix);
        GraphNode<String> nodeB = new GraphNode<>("Node B", 2.0, 2.0, matrix);

        // Connect nodes undirected
        nodeA.connectToNodeUndirected(nodeB);

        // Verify the connection is undirected
        assertTrue(matrix.amat[nodeA.nodeId][nodeB.nodeId], "There should be an undirected edge from nodeA to nodeB.");
        assertTrue(matrix.amat[nodeB.nodeId][nodeA.nodeId], "There should be an undirected edge from nodeB to nodeA.");
    }

    @Test
    void testNodeLimitExceeded() {
        // Setup within the method
        AdjacencyMatrix matrix = new AdjacencyMatrix(1); // very small matrix to test limit
        GraphNode<String> nodeA = new GraphNode<>("Node A", 1.0, 1.0, matrix);

        // Verify that an exception is thrown when trying to add more nodes than the limit
        Exception exception = assertThrows(IllegalStateException.class, () -> new GraphNode<>("Node B", 2.0, 2.0, matrix),
                "Should throw an exception when adding more nodes than the matrix can handle.");
        assertEquals("Too many nodes added to the graph", exception.getMessage());
    }
}
